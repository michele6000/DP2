package it.polito.dp2.BIB.sol3.client;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import it.polito.dp2.BIB.ass3.ItemReader;
import it.polito.dp2.BIB.sol3.client.Item;

public class ItemReaderImpl implements ItemReader {

	private Item item;
	private Long id=null;
	private Set<ItemReader> citingItems;
	
	public ItemReaderImpl(Item i) {
		this.item = i;
	}
	
	public ItemReaderImpl(it.polito.dp2.BIB.sol3.client.Items.Item i) {
		item = new Item();
		item.setTitle(i.getTitle());
		item.setSubtitle(i.getSubtitle());
		List<String> authors = item.getAuthor();
		authors.addAll(i.getAuthor());
		item.setSelf(i.getSelf());
		item.setTargets(i.getTargets());
		item.setCitedBy(i.getCitedBy());
		item.setCitations(i.getCitations());
		item.setArticle(i.getArticle());
		item.setBook(i.getBook());
		citingItems = new HashSet<ItemReader>();
		id = Long.parseLong(item.getSelf().substring(item.getSelf().lastIndexOf('/') + 1, item.getSelf().length()));

	}

	public ItemReaderImpl(it.polito.dp2.BIB.sol3.client.BookshelfItems.Item i) {
		item = new Item();
		item.setTitle(i.getTitle());
		item.setSubtitle(i.getSubtitle());
		List<String> authors = item.getAuthor();
		authors.addAll(i.getAuthor());
		item.setSelf(i.getSelf());
		item.setTargets(i.getTargets());
		item.setCitedBy(i.getCitedBy());
		item.setCitations(i.getCitations());
		item.setArticle(i.getArticle());
		item.setBook(i.getBook());
		citingItems = new HashSet<ItemReader>();
		id = Long.parseLong(item.getSelf().substring(item.getSelf().lastIndexOf('/') + 1, item.getSelf().length()));

	}
	
	public Item getItem () {
		return item;
	}

	public Long getId()  {
		//TODO
		return id;
	}
	
	public String getSelf() {
		return item.getSelf();
	}
	
	@Override
	public String[] getAuthors() {
		List<String> authors = item.getAuthor();
		String[] a = new String[authors.size()];
		for (int i = 0; i < authors.size(); i++)
			a[i] = authors.get(i);
		return a;
	}

	@Override
	public Set<ItemReader> getCitingItems() {
		//TODO
		return citingItems;
	}

	@Override
	public String getSubtitle() {
		return item.getSubtitle();
	}

	@Override
	public String getTitle() {
		return item.getTitle();
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Item id="+id+" Title="+item.getTitle());
		if (item.getSubtitle() != null)
			sb.append(" Subtitle="+item.getSubtitle());
		sb.append("\nAuthors="+item.getAuthor());
		sb.append("\nCiting Items=");
		for (it.polito.dp2.BIB.ass3.ItemReader i : citingItems)  {
			sb.append(i.getTitle()+" ");
		}
		return sb.toString();
	}
}
