package it.polito.dp2.BIB.sol3.client;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import it.polito.dp2.BIB.ass3.Bookshelf;
import it.polito.dp2.BIB.ass3.DestroyedBookshelfException;
import it.polito.dp2.BIB.ass3.ItemReader;
import it.polito.dp2.BIB.ass3.ServiceException;
import it.polito.dp2.BIB.ass3.TooManyItemsException;
import it.polito.dp2.BIB.ass3.UnknownItemException;

public class BookshelfImpl implements Bookshelf {
	javax.ws.rs.client.Client client;
	boolean destroyed;
	String name;
	WebTarget bookshelvesTarget;
	WebTarget selfTarget;
	WebTarget itemsTarget;
	Bookshelves.Bookshelf bookshelf;

	public BookshelfImpl(Bookshelves.Bookshelf bookshelf, WebTarget bookshelvesTarget) {
		client = ClientBuilder.newClient();
		this.bookshelvesTarget = bookshelvesTarget;
		this.bookshelf = bookshelf;
		this.name = bookshelf.getName();
		this.selfTarget = client.target(bookshelf.getSelf());
		this.itemsTarget = client.target(bookshelf.getItems());
		this.destroyed = false;
	}

	@Override
	public void addItem(ItemReader item)
			throws DestroyedBookshelfException, UnknownItemException, ServiceException, TooManyItemsException {
		if (destroyed)
			throw new DestroyedBookshelfException();

		try {
			ItemReaderImpl req = (ItemReaderImpl) item;

			BookshelfItem bi = new BookshelfItem();
			bi.setItem(req.getItem());
			Long idItem = req.getId();
			Response response = itemsTarget.path(idItem + "").request(MediaType.APPLICATION_JSON_TYPE)
					.put(Entity.json(bi));
			if (response.getStatus() == 409)
				throw new TooManyItemsException();
			if (response.getStatus() != 201)
				throw new ServiceException();
		} catch (ClassCastException e ) {
			throw new UnknownItemException();
		}
	}

	@Override
	public void destroyBookshelf() throws DestroyedBookshelfException, ServiceException {
		if (destroyed)
			throw new DestroyedBookshelfException();

		Response res = selfTarget.request(MediaType.APPLICATION_JSON_TYPE).delete();

		if (res.getStatus() == 404)
			throw new ServiceException();
		else if (res.getStatus() != 204)
			throw new ServiceException();
		else {
			this.bookshelf = null;
			this.destroyed = true;
		}
	}

	@Override
	public String getName() throws DestroyedBookshelfException {
		if (destroyed)
			throw new DestroyedBookshelfException();
		else
			return this.name;
	}

	@Override
	public Set<ItemReader> getItems() throws DestroyedBookshelfException, ServiceException {
		if (destroyed)
			throw new DestroyedBookshelfException();

		Set<ItemReader> items = new HashSet<>();
		BookshelfItems returnedItems = itemsTarget.request(MediaType.APPLICATION_JSON_TYPE)
				.get(BookshelfItems.class);

		for (it.polito.dp2.BIB.sol3.client.BookshelfItems.Item i : returnedItems.getItem()) {
			items.add(new ItemReaderImpl(i));
		}
		return items;
	}

	@Override
	public int getNumberOfReads() throws DestroyedBookshelfException {
		if (destroyed)
			throw new DestroyedBookshelfException();
		
		String val = selfTarget.path("reads").request(MediaType.TEXT_PLAIN_TYPE).get(String.class);
		return Integer.parseInt(val);
	}

	@Override
	public void removeItem(ItemReader item) throws DestroyedBookshelfException, UnknownItemException, ServiceException {
		if (destroyed)
			throw new DestroyedBookshelfException();

		try {
			ItemReaderImpl req = (ItemReaderImpl) item;
	
			// extract id of item in order to perform DELETE
			String itemID = req.getSelf().substring(req.getSelf().lastIndexOf("/") + 1, req.getSelf().length());
	
			Response response = itemsTarget.path(itemID).request(MediaType.APPLICATION_JSON_TYPE)
					.delete();

			if (response.getStatus() == 404) {
				destroyed = true;
				throw new DestroyedBookshelfException();
			}

			if (response.getStatus() != 204)
				throw new ServiceException();
		} catch (ClassCastException e ) {
			throw new UnknownItemException();
		}
	}

}
