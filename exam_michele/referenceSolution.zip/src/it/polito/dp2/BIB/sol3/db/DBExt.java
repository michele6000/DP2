package it.polito.dp2.BIB.sol3.db;

import java.math.BigInteger;
import java.util.Collection;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

public interface DBExt extends DB {

	/**
	 * Create a new bookshelf in the DB
	 * @param name the name of the bookshelf to be created
	 * @return the name of the created bookshelf or null if the bookshelf could not be created because the name was null or a bookshelf with the same name already exists
	 */
	public String createBookshelf(String name);
	
	/**
	 * Checks whether a bookshelf with the given name exists
	 * @param name the name of the bookshelf to be checked
	 * @return true if the bookshelf exists
	 */
	public boolean getBookshelf(String name);
	
	/**
	 * Remove the bookshelf with the given name from the DB
	 * param name the name of the bookshelf to be removed
	 * @throws UnknownBookshelfException if a bookshelf with the given name does not exist or the name is null
	 */
	public void removeBookshelf (String name) throws UnknownBookshelfException;
	
	/**
	 * Get all the bookshelves in the DB, whose names match a given prefix
	 * @param prefix the prefix
	 * @return a collection of strings that represent the names of the selected bookshelves
	 */
	public Collection<String> getBookshelves (String prefix);
	
	/**
	 * Get the items in a bookshelf with the given name
	 * @param name the name of the bookshelf to be retrieved
	 * @return an ItemPage object that contains the search results (one page) or null if it does not exist
	 * @throws UnknownBookshelfException if a bookshelf with the given name does not exist or the name is null
	 * @throws Exception if the items cannot be obtained for some other reason
	 */
	public ItemPage getBookshelfItems (String name) throws UnknownBookshelfException, Exception;
	
	/**
	 * Add an item to a bookshelf
	 * @param id the id of the item to add
	 * @param name the name of the bookshelf
	 * @return true if the item has been added, false it it was already in the bookshelf
	 * @throws UnknownItemException if an item with the given id does not exist or the id is null
	 * @throws UnknownBookshelfException if a bookshelf with the given name does not exist or the name is null
	 * @throws TooManyItemsException if the item cannot be added because the maximum number of items has been reached in the bookshelf
	 * @throws Exception if the item cannot be added to the bookshelf for other reasons
	 */
	public boolean addItemToBookshelf(BigInteger id, String name) throws UnknownItemException, UnknownBookshelfException, TooManyItemsException, Exception;

	/**
	 * Remove an item from a bookshelf
	 * @param id the id of the item to remove
	 * @param name the name of the bookshelf
	 * @return true if the item has been removed or false if the item was not present in the bookshelf
	 * @throws UnknownItemException if an item with the given id does not exist or the id is null
	 * @throws UnknownBookshelfException if a bookshelf with the given name does not exist or the name is null
	 * @throws Exception if the item cannot be removed for other reasons
	 */
	public boolean removeItemFromBookshelf(BigInteger id, String name) throws UnknownItemException, UnknownBookshelfException, Exception;

	/**
	 * Get the  counter associated with the bookshelf with the given name
	 * @param name
	 * @return
	 */
	public AtomicLong getBookshelfCounter(String name);
	
}
