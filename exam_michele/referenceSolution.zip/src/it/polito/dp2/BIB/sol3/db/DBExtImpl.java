package it.polito.dp2.BIB.sol3.db;

import java.math.BigInteger;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import it.polito.dp2.BIB.sol3.neo4j.jaxb.NodeType;
import it.polito.dp2.BIB.sol3.service.SearchScope;
import it.polito.dp2.BIB.sol3.service.jaxb.Citation;
import it.polito.dp2.BIB.sol3.service.jaxb.Item;


/**
 * This class acts as the implementation of the extended DB interface DBExt
 * Internally, it uses 
 * - a DB implementation (db), which is used to store bibliography items and citations
 * - a BookshelvesDB (bdb), which is delegated to store the bookshelf-related information
 * - a map (bookshelvesByItem) that maps each item id onto the set of bookshelves this item is currently in.
 * This last map is used as a way to speed-up item delete operations and it relates the two
 * previous storage units.
 */
public class DBExtImpl implements DBExt {
	private static DBExtImpl dbImpl = new DBExtImpl();
	private ConcurrentHashMap<BigInteger,ConcurrentSkipListSet<Bookshelf>> bookshelvesByItem;
	DB db;
	BookshelvesDB bdb;
	
	private DBExtImpl() {
		bookshelvesByItem = new ConcurrentHashMap<BigInteger,ConcurrentSkipListSet<Bookshelf>>();
		db = Neo4jDB.getNeo4jDB();
		bdb = BookshelvesDB.getBookshelvesDB();
	}
	
	public static DBExtImpl getDBExtImpl() {
		return dbImpl;
	}

	@Override
	public BigInteger createItem(Item item) throws Exception {
		return db.createItem(item);
	}

	@Override
	public ItemPage getItems(SearchScope scope, String keyword, int beforeInclusive, int afterInclusive,
			BigInteger page) throws Exception {
		return db.getItems(scope, keyword, beforeInclusive, afterInclusive, page);
	}

	@Override
	public Item getItem(BigInteger id) throws Exception {
		return db.getItem(id);
	}

	@Override
	public Item updateItem(BigInteger id, Item item) throws Exception {
		return db.updateItem(id, item);
	}

	@Override
	public synchronized BigInteger deleteItem(BigInteger id) throws ConflictInOperationException, Exception {
		// try to remove the item from the db (if it fails it throws an exception, which stops the delete operation)
		db.deleteItem(id);
		// remove the item from all the bookshelves that contain it
		for (Bookshelf b: bookshelvesByItem.get(id))
			b.removeItem(id);
		return null;
	}

	@Override
	public Citation createItemCitation(BigInteger id, BigInteger tid, Citation citation)
			throws BadRequestInOperationException, Exception {
		return db.createItemCitation(id, tid, citation);
	}

	@Override
	public boolean deleteItemCitation(BigInteger id, BigInteger tid) throws Exception {
		return db.deleteItemCitation(id, tid);
	}

	@Override
	public Citation getItemCitation(BigInteger id, BigInteger tid) throws Exception {
		return db.getItemCitation(id, tid);
	}

	@Override
	public ItemPage getItemCitations(BigInteger id, BigInteger page) throws Exception {
		return db.getItemCitations(id, page);
	}

	@Override
	public ItemPage getItemCitedBy(BigInteger id, BigInteger page) throws Exception {
		return db.getItemCitedBy(id, page);
	}

	@Override
	public String createBookshelf(String name) {
		if (bdb.createBookshelf(name)!=null)
			return name;
		else
			return null;
	}
	
	@Override
	public boolean getBookshelf(String name) {
		if (bdb.getBookshelf(name)==null)
			return false;
		else
			return true;
	}

	@Override
	public synchronized void removeBookshelf(String name) throws UnknownBookshelfException {
		Bookshelf removed; // the removed bookshelf object
		// remove the bookshelf (can fail if the bookshelf does not exist)
		if ((removed=bdb.removeBookshelf(name))==null)
			throw new UnknownBookshelfException();
		// if bookshelf was removed, remove it also from the set of bookshelves of each contained item
		for (BigInteger id:removed.getItems()) {
			ConcurrentSkipListSet<Bookshelf> set = bookshelvesByItem.get(id);
			set.remove(removed);
			if (set.isEmpty())
				bookshelvesByItem.remove(id);
		}
	}

	@Override
	public Collection<String> getBookshelves(String prefix) {
		Collection<Bookshelf> bookshelves = bdb.getBookshelves(prefix);
		HashSet<String> retval = new HashSet<String>();
		for (Bookshelf b:bookshelves) {
			retval.add(b.getName());
		}
		return retval;	
	}

	@Override
	public ItemPage getBookshelfItems(String name) throws UnknownBookshelfException, Exception {
		Bookshelf b = bdb.getBookshelf(name);
		if (b==null)
			throw new UnknownBookshelfException();
		ItemPage itemPage = new ItemPage();
		Map<BigInteger,Item> map = itemPage.getMap();
		for (BigInteger id:b.getItems()) {
			Item item = db.getItem(id);
			map.put(id,item);
		}
		itemPage.setTotalPages(BigInteger.ONE);
		return itemPage;
	}

	@Override
	public synchronized boolean addItemToBookshelf(BigInteger id, String name)
			throws UnknownItemException, UnknownBookshelfException, TooManyItemsException, Exception {
		Bookshelf b = bdb.getBookshelf(name);
		if (b==null)
			throw new UnknownBookshelfException();
		Item i = db.getItem(id);
		if (i==null)
			throw new UnknownItemException();
		if (b.addItem(id)==false)
			return false;
		else {
			ConcurrentSkipListSet<Bookshelf> newSet = new ConcurrentSkipListSet<Bookshelf>();
			newSet.add(b);
			ConcurrentSkipListSet<Bookshelf> oldSet = bookshelvesByItem.putIfAbsent(id, newSet);
			if (oldSet!=null)
				oldSet.add(b);
			return true;
		}
	}

	@Override
	public synchronized boolean removeItemFromBookshelf(BigInteger id, String name)
			throws UnknownItemException, UnknownBookshelfException, Exception {
		Bookshelf b = bdb.getBookshelf(name);
		if (b==null)
			throw new UnknownBookshelfException();
		Item i = db.getItem(id);
		if (i==null)
			throw new UnknownItemException();
		if (b.removeItem(id)==false)
			return false;
		else {
			bookshelvesByItem.get(id).remove(b);
			return true;
		}
	}

	@Override
	public AtomicLong getBookshelfCounter(String name) {
		Bookshelf b = bdb.getBookshelf(name);
		if (b!=null)
			return b.getCounter();
		else
			return null;
	}

}
