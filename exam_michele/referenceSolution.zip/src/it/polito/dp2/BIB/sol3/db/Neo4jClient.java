package it.polito.dp2.BIB.sol3.db;

import java.math.BigInteger;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.BadRequestException;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.ProcessingException;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import it.polito.dp2.BIB.sol3.neo4j.jaxb.CypherRequest;
import it.polito.dp2.BIB.sol3.neo4j.jaxb.CypherRequest.Statements;
import it.polito.dp2.BIB.sol3.neo4j.jaxb.CypherResponse;
import it.polito.dp2.BIB.sol3.neo4j.jaxb.CypherResponse.Results;
import it.polito.dp2.BIB.sol3.neo4j.jaxb.Data;
import it.polito.dp2.BIB.sol3.neo4j.jaxb.NodeType;
import it.polito.dp2.BIB.sol3.neo4j.jaxb.ObjectFactory;
import it.polito.dp2.BIB.sol3.neo4j.jaxb.RelationshipType;
import it.polito.dp2.BIB.sol3.neo4j.jaxb.TraverseRequest;

import it.polito.dp2.BIB.sol3.service.SearchScope;

public class Neo4jClient {
	Client client;
	WebTarget target;
	String uri = "http://localhost:7474/db";
	private ObjectFactory of = new ObjectFactory();

	public Neo4jClient() {
		client = ClientBuilder.newClient();		
		target = client.target(uri).path("data");
	}
	
	public void close() {
		client.close();
	}

	public NodeType createNode(Data data) throws Neo4jClientException {
		try {
			NodeType node = target.path("node")
				  .request(MediaType.APPLICATION_JSON_TYPE)
				  .post(Entity.json(data), NodeType.class);
			return node;
		} catch (WebApplicationException|ProcessingException e) {
			throw new Neo4jClientException(e);
		}
	}

	public List<NodeType> searchNode(SearchScope scope, String keyword, int beforeInclusive, int afterInclusive) throws Neo4jClientException {
		StringBuffer s = new StringBuffer("MATCH(n) WHERE ");
		if (scope==SearchScope.ARTICLES)
			s.append("n.type = \"").append("article").append("\" AND ");
		else if (scope==SearchScope.BOOKS)
			s.append("n.type = \"").append("book").append("\" AND ");
		s.append("n.title CONTAINS \"").append(keyword).append('"').append(' ');
		s.append("AND n.year <= ").append(beforeInclusive).append(' ');
		s.append("AND n.year >= ").append(afterInclusive);
		s.append(" RETURN n");
		
		CypherRequest request = new CypherRequest();
		Statements stat = new Statements();
		stat.setStatement(s.toString());
		stat.getResultDataContents().add("REST");
		request.getStatements().add(stat);
		
		try {
			CypherResponse response = target.path("transaction").path("commit")
				  .request(MediaType.APPLICATION_JSON_TYPE)
				  .post(Entity.json(request), CypherResponse.class);
			List<NodeType> nodes = new ArrayList<NodeType>();
			if (response.getErrors().size()!=0 || response.getResults()==null)
				throw new Neo4jClientException("Error in search");
			Results results = response.getResults().get(0);
			if (results!=null)
			for (it.polito.dp2.BIB.sol3.neo4j.jaxb.CypherResponse.Results.Data r:results.getData()) {
				nodes.addAll(r.getRest());
			}
			return nodes;
		} catch (WebApplicationException|ProcessingException e) {
			throw new Neo4jClientException(e);
		}
	}

	public NodeType getNode(BigInteger id) throws Neo4jClientException {
		try {
			NodeType node = target.path("node").path(id.toString())
				  .request(MediaType.APPLICATION_JSON_TYPE)
				  .get(NodeType.class);
			return node;
		} catch (NotFoundException e1) {
			return null;
		} catch (WebApplicationException|ProcessingException e2) {
			throw new Neo4jClientException(e2);
		}
	}

	public Data updateNode(BigInteger id, Data data) throws Neo4jClientException {
		try {
			Response response = target.path("node").path(id.toString()).path("properties")
				  .request(MediaType.APPLICATION_JSON_TYPE)
				  .put(Entity.json(data));
			int status = response.getStatus();
			if (status==204)
				return data;
			else if (status==404)
				return null;
			else
				throw new Neo4jClientException("Neo4j put not successful: "+response.getStatusInfo());
		} catch (ProcessingException e) {
			throw new Neo4jClientException(e);
		}	
	}

	public BigInteger deleteNode(BigInteger id) throws Neo4jClientException, ConflictInOperationException {
			Response response = target.path("node").path(id.toString())
				  .request()
				  .delete();
			int status = response.getStatus();
			if (status==204)
				return id;
			else if (status==404)
				return null;
			else if (status==409)
				throw new ConflictInOperationException();
			else
				throw new Neo4jClientException("Neo4j get not successful: "+response.getStatusInfo());
	}

	public RelationshipType createRelationship(BigInteger id, BigInteger tid) throws Neo4jClientException, BadRequestInOperationException {
		WebTarget t1 = target.path("node").path(id.toString());
		WebTarget t2 = target.path("node").path(tid.toString());
		
		RelationshipType relationship = of.createRelationshipType();
		relationship.setTo(t2.getUri().toString());
		relationship.setType("CitedBy");
		try {
			t1
			  .path("/relationships")
		 	  .request(MediaType.APPLICATION_JSON_TYPE)
		 	  .post(Entity.json(relationship));
			return relationship;
		} catch (NotFoundException e1) {
			return null;
		} catch (BadRequestException e2) {
			throw new BadRequestInOperationException();
		} catch (WebApplicationException|ProcessingException|IllegalArgumentException e) {
			throw new Neo4jClientException(e);
		}
	}

	public boolean deleteRelationship(BigInteger id, BigInteger tid) throws Neo4jClientException {
		URI uri = getRelationship(id,tid);
		if (uri==null)
			return false;
		else {
			Response response = client.target(uri).request().delete();
			int status = response.getStatus();
			if (status==204)
				return true;
			else if (status==404)
				return false;
			else
				throw new Neo4jClientException("Neo4j delete not successful: "+response.getStatusInfo());
		}
	}

	public URI getRelationship(BigInteger id, BigInteger tid) throws Neo4jClientException {
		String s = "MATCH(n)-[r]->(m) WHERE id(n)="+id.toString()+" AND id(m)="+tid.toString()+" RETURN r";
		
		CypherRequest request = new CypherRequest();
		Statements stat = new Statements();
		stat.setStatement(s.toString());
		stat.getResultDataContents().add("REST");
		request.getStatements().add(stat);
		
		try {
			CypherResponse response = target.path("transaction").path("commit")
				  .request(MediaType.APPLICATION_JSON_TYPE)
				  .post(Entity.json(request), CypherResponse.class);
			if (response.getErrors().size()!=0 || response.getResults()==null)
				throw new Neo4jClientException("Error in search");
			Results results = response.getResults().get(0);
			if (results.getData().size()==0)
				return null;
			CypherResponse.Results.Data data = results.getData().get(0);
			URI uri = new URI(data.getRest().get(0).getSelf());
			return uri;
		} catch (WebApplicationException|ProcessingException|URISyntaxException e) {
			throw new Neo4jClientException(e);
		}
		
	}

	public List<NodeType> getNextNodes(BigInteger id, String direction) throws Neo4jClientException {
		TraverseRequest request = of.createTraverseRequest();
		request.setUniqueness("node_global");
		RelationshipType rel = of.createRelationshipType();
		rel.setDirection(direction);
		rel.setType("CitedBy");
		request.getRelationships().add(rel);
		List<NodeType> retval = new ArrayList<NodeType>();
		try {
			List<NodeType> nodes =
			   target.path("node").path(id.toString())
			  .path("/traverse")
			  .path("/node")
		 	  .request(MediaType.APPLICATION_JSON_TYPE)
		 	  .post(Entity.json(request), new GenericType<List<NodeType>>() {});
			for (NodeType node:nodes) {
				retval.add(node);
			}
			return retval;
		} catch (NotFoundException e1) {
			return null;
		} catch (WebApplicationException | ProcessingException e) {
			throw new Neo4jClientException(e);
		}
	}
}
