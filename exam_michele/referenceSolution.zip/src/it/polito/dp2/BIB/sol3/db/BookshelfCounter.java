package it.polito.dp2.BIB.sol3.db;

public class BookshelfCounter {

	private static final int max=20;
	private int current;
			
	public BookshelfCounter() {
		current=max;
	}
	
	public int get() {
		return current;
	}
	
	public synchronized boolean decrement() {
		if (current>0) {
			--current; 
			return true;
		}
		else return false;
	}
	
	public synchronized void increment() {
		current++;
	}
	
	public int getMax() {
		return max;
	}

}
