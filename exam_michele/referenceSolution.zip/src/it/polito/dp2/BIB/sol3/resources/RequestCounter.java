package it.polito.dp2.BIB.sol3.resources;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/biblio/numberOfRequests")
public class RequestCounter {
	private CounterImpl counter;

	public RequestCounter() {
		counter = CounterImpl.getCounter();
	}
	
	@GET
	@Produces({MediaType.TEXT_PLAIN})
	public int getCount() {
		return counter.value();
	}	
}
