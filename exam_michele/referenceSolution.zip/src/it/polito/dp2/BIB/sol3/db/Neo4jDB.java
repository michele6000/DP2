package it.polito.dp2.BIB.sol3.db;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;


import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import it.polito.dp2.BIB.sol3.service.jaxb.ArticleType;
import it.polito.dp2.BIB.sol3.service.jaxb.BookType;
import it.polito.dp2.BIB.sol3.service.jaxb.Citation;
import it.polito.dp2.BIB.sol3.service.jaxb.Item;
import it.polito.dp2.BIB.sol3.neo4j.jaxb.Data;
import it.polito.dp2.BIB.sol3.neo4j.jaxb.ItemType;
import it.polito.dp2.BIB.sol3.neo4j.jaxb.NodeType;
import it.polito.dp2.BIB.sol3.service.SearchScope;

public class Neo4jDB implements DB {
	private static DB neo4jDB = new Neo4jDB();
	private Neo4jClient client;

	private Neo4jDB() {
		client = new Neo4jClient();
	}
	
	public static DB getNeo4jDB() {
		return neo4jDB;
	}

	/* (non-Javadoc)
	 * @see it.polito.dp2.BIB.sol3.db.DB#createItem(it.polito.dp2.BIB.sol3.service.jaxb.Item)
	 */
	@Override
	public BigInteger createItem(Item item) throws Exception {
		NodeType node = client.createNode(fromItem(item));
		return node.getMetadata().getId();
	}

	/* (non-Javadoc)
	 * @see it.polito.dp2.BIB.sol3.db.DB#getItems(it.polito.dp2.BIB.sol3.service.SearchScope, java.lang.String, int, int, java.math.BigInteger)
	 */
	@Override
	public ItemPage getItems(SearchScope scope, String keyword, int beforeInclusive,
			int afterInclusive, BigInteger page) throws Exception {
		//TODO: manage pages
		ItemPage itemPage = new ItemPage();
		if (page.equals(BigInteger.ONE)) {
			List<NodeType> nodes = client.searchNode(scope, keyword, beforeInclusive, afterInclusive);
			Map<BigInteger,Item> map = itemPage.getMap();
			for (NodeType node:nodes) {
				map.put(node.getMetadata().getId(),fromData(node.getData()));
			}
			itemPage.setTotalPages(BigInteger.ONE);
		}		
		return itemPage;
	}
	
	private Data fromItem(Item item) {
		Data data = new Data();
		data.setTitle(item.getTitle());
		data.setSubtitle(item.getSubtitle());
		data.getAuthor().addAll(item.getAuthor());
		ArticleType article = item.getArticle();
		BookType book = item.getBook();
		if (article!=null) {
			data.setType(ItemType.ARTICLE);
			data.setJournal(article.getJournal());
			data.setYear(BigInteger.valueOf(article.getVolume().getYear()));
			data.setNumber(article.getNumber());
		} else if (book!=null) {
			data.setType(ItemType.BOOK);
			data.setISBN(book.getISBN());
			data.setPublisher(book.getPublisher());
			data.setYear(BigInteger.valueOf(book.getYear().getYear()));
		}
		return data;
	}
	
	private Item fromData(Data data) throws DatatypeConfigurationException {
		Item item = new Item();
		item.setTitle(data.getTitle());
		item.setSubtitle(data.getSubtitle());
		item.getAuthor().addAll(data.getAuthor());
		XMLGregorianCalendar calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar();
		calendar.setYear(data.getYear());
		if (data.getType()!=null)
			if (data.getType().equals(ItemType.ARTICLE)) {
				ArticleType article = new ArticleType();
				article.setJournal(data.getJournal());
				article.setVolume(calendar);
				article.setNumber(data.getNumber());
				item.setArticle(article);
			} else {
				BookType book = new BookType();
				book.setISBN(data.getISBN());
				book.setPublisher(data.getPublisher());
				book.setYear(calendar);
				item.setBook(book);
			}
		return item;
	}

	/* (non-Javadoc)
	 * @see it.polito.dp2.BIB.sol3.db.DB#getItem(java.math.BigInteger)
	 */
	@Override
	public Item getItem(BigInteger id) throws Exception {
		NodeType node = client.getNode(id);
		if (node==null)
			return null;
		else
			return fromData(node.getData());
	}

	/* (non-Javadoc)
	 * @see it.polito.dp2.BIB.sol3.db.DB#updateItem(java.math.BigInteger, it.polito.dp2.BIB.sol3.service.jaxb.Item)
	 */
	@Override
	public Item updateItem(BigInteger id, Item item) throws Exception {
		if (client.updateNode(id, fromItem(item))==null) {
			return null;
		}	
		else
			return item;
	}

	/* (non-Javadoc)
	 * @see it.polito.dp2.BIB.sol3.db.DB#deleteItem(java.math.BigInteger)
	 */
	@Override
	public BigInteger deleteItem(BigInteger id) throws ConflictInOperationException, Exception {
		return client.deleteNode(id);
	}

	/* (non-Javadoc)
	 * @see it.polito.dp2.BIB.sol3.db.DB#createItemCitation(java.math.BigInteger, java.math.BigInteger, it.polito.dp2.BIB.sol3.service.jaxb.Citation)
	 */
	@Override
	public Citation createItemCitation(BigInteger id, BigInteger tid, Citation citation) throws BadRequestInOperationException, Exception {
		if (client.createRelationship(id,tid)==null)
			return null;
		else
			return citation;
		
	}

	/* (non-Javadoc)
	 * @see it.polito.dp2.BIB.sol3.db.DB#deleteItemCitation(java.math.BigInteger, java.math.BigInteger)
	 */
	@Override
	public boolean deleteItemCitation(BigInteger id, BigInteger tid) throws Exception {
		return client.deleteRelationship(id,tid);
	}

	/* (non-Javadoc)
	 * @see it.polito.dp2.BIB.sol3.db.DB#getItemCitation(java.math.BigInteger, java.math.BigInteger)
	 */
	@Override
	public Citation getItemCitation(BigInteger id, BigInteger tid) throws Exception {
		if(client.getRelationship(id,tid)==null)
			return null;
		else {
			return new Citation();
		}
	}

	/* (non-Javadoc)
	 * @see it.polito.dp2.BIB.sol3.db.DB#getItemCitations(java.math.BigInteger, java.math.BigInteger)
	 */
	@Override
	public ItemPage getItemCitations(BigInteger id, BigInteger page) throws Exception {
		return getItemCitations(id, page, "in");
	}

	private ItemPage getItemCitations(BigInteger id, BigInteger page, String direction)
			throws Neo4jClientException, DatatypeConfigurationException {
		//TODO: manage pages
		ItemPage itemPage = new ItemPage();
		if (page.equals(BigInteger.ONE)) {
			List<NodeType> nodes = client.getNextNodes(id,direction);
			if (nodes==null)
				return null;
			Map<BigInteger,Item> map = itemPage.getMap();
			for (NodeType node:nodes) {
				map.put(node.getMetadata().getId(),fromData(node.getData()));
			}
			itemPage.setTotalPages(BigInteger.ONE);
		}		
		return itemPage;
	}

	/* (non-Javadoc)
	 * @see it.polito.dp2.BIB.sol3.db.DB#getItemCitedBy(java.math.BigInteger, java.math.BigInteger)
	 */
	@Override
	public ItemPage getItemCitedBy(BigInteger id, BigInteger page) throws Exception {
		return getItemCitations(id, page, "out");
	}

	
}
