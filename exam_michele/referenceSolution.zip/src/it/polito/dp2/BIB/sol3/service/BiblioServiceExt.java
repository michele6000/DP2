package it.polito.dp2.BIB.sol3.service;

import java.math.BigInteger;
import java.util.Collection;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;

import javax.ws.rs.core.UriInfo;

import it.polito.dp2.BIB.sol3.db.BadRequestInOperationException;
import it.polito.dp2.BIB.sol3.db.BookshelvesDB;
import it.polito.dp2.BIB.sol3.db.ConflictInOperationException;
import it.polito.dp2.BIB.sol3.db.DB;
import it.polito.dp2.BIB.sol3.db.DBExt;
import it.polito.dp2.BIB.sol3.db.DBExtImpl;
import it.polito.dp2.BIB.sol3.db.ItemPage;
import it.polito.dp2.BIB.sol3.db.Neo4jDB;
import it.polito.dp2.BIB.sol3.db.TooManyItemsException;
import it.polito.dp2.BIB.sol3.db.UnknownBookshelfException;
import it.polito.dp2.BIB.sol3.db.UnknownItemException;
import it.polito.dp2.BIB.sol3.service.jaxb.Citation;
import it.polito.dp2.BIB.sol3.service.jaxb.Item;
import it.polito.dp2.BIB.sol3.service.jaxb.Items;
import it.polito.dp2.BIB.sol3.service.jaxb.Bookshelf;
import it.polito.dp2.BIB.sol3.service.jaxb.BookshelfItem;
import it.polito.dp2.BIB.sol3.service.jaxb.BookshelfItems;
import it.polito.dp2.BIB.sol3.service.jaxb.Bookshelves;
import it.polito.dp2.BIB.sol3.service.jaxb.ObjectFactory;
import it.polito.dp2.BIB.sol3.service.util.ResourceUtilsExt;

public class BiblioServiceExt {
	private DBExt db = DBExtImpl.getDBExtImpl();
	ResourceUtilsExt rutil;
	ObjectFactory of = new ObjectFactory();

	public BiblioServiceExt(UriInfo uriInfo) {
		rutil = new ResourceUtilsExt((uriInfo.getBaseUriBuilder()));
	}
	
	public Items getItems(SearchScope scope, String keyword, int beforeInclusive, int afterInclusive, BigInteger page) throws Exception {
		ItemPage itemPage = db.getItems(scope,keyword,beforeInclusive,afterInclusive,page);

		Items items = new Items();
		List<Item> list = items.getItem();
		
		Set<Entry<BigInteger,Item>> set = itemPage.getMap().entrySet();
		for(Entry<BigInteger,Item> entry:set) {
			Item item = entry.getValue();
			rutil.completeItem(item, entry.getKey());
			list.add(item);
		}
		items.setTotalPages(itemPage.getTotalPages());
		items.setPage(page);
		return items;
	}

	public Item getItem(BigInteger id) throws Exception {
			Item item = db.getItem(id);
			if (item!=null)
				rutil.completeItem(item, id);
			return item;
	}

	public Item updateItem(BigInteger id, Item item) throws Exception {
		Item ret = db.updateItem(id, item);
		if (ret!=null) {
			rutil.completeItem(item, id);
			return item;
		} else
			return null;
	}

	public Item createItem(Item item) throws Exception {
		BigInteger id = db.createItem(item);
		if (id==null)
			throw new Exception("Null id");
		rutil.completeItem(item, id);
		return item;
	}

	public BigInteger deleteItem(BigInteger id) throws ConflictServiceException, Exception {
		try {
			return db.deleteItem(id);
		} catch (ConflictInOperationException e) {
			throw new ConflictServiceException();
		}
	}

	public Citation createItemCitation(BigInteger id, BigInteger tid, Citation citation) throws Exception {
		try {
			return db.createItemCitation(id, tid, citation);
		} catch (BadRequestInOperationException e) {
			throw new BadRequestServiceException();
		}
	}

	public Citation getItemCitation(BigInteger id, BigInteger tid) throws Exception {
		Citation citation = db.getItemCitation(id,tid);
		if (citation!=null)
			rutil.completeCitation(citation, id, tid);
		return citation;
	}

	public boolean deleteItemCitation(BigInteger id, BigInteger tid) throws Exception {
		return db.deleteItemCitation(id, tid);
	}

	public Items getItemCitations(BigInteger id) throws Exception {
		ItemPage itemPage = db.getItemCitations(id, BigInteger.ONE);
		if (itemPage==null)
			return null;

		Items items = new Items();
		List<Item> list = items.getItem();
		
		Set<Entry<BigInteger,Item>> set = itemPage.getMap().entrySet();
		for(Entry<BigInteger,Item> entry:set) {
			Item item = entry.getValue();
			rutil.completeItem(item, entry.getKey());
			list.add(item);
		}
		items.setTotalPages(itemPage.getTotalPages());
		items.setPage(BigInteger.ONE);
		return items;
	}

	public Items getItemCitedBy(BigInteger id) throws Exception {
		ItemPage itemPage = db.getItemCitedBy(id, BigInteger.ONE);
		if (itemPage==null)
			return null;

		Items items = new Items();
		List<Item> list = items.getItem();
		
		Set<Entry<BigInteger,Item>> set = itemPage.getMap().entrySet();
		for(Entry<BigInteger,Item> entry:set) {
			Item item = entry.getValue();
			rutil.completeItem(item, entry.getKey());
			list.add(item);
		}
		items.setTotalPages(itemPage.getTotalPages());
		items.setPage(BigInteger.ONE);
		return items;
	}
	
	public Bookshelf createBookshelf(String name) {
		if (db.createBookshelf(name)==null)
			return null;
		else {
			Bookshelf b = of.createBookshelf();
			b.setName(name);
			rutil.completeBookshelf(b);
			return b;
		}	
	}
	
	public Bookshelf getBookshelf(String name) {
		if (db.getBookshelf(name)) {
			Bookshelf b = of.createBookshelf();
			b.setName(name);
			rutil.completeBookshelf(b);
			return b;
		} else
			return null;
	}
	
	public Bookshelves getBookshelves(String prefix, BigInteger page) {
		Collection<String> names = db.getBookshelves(prefix);
		Bookshelves retval = of.createBookshelves();
		List<Bookshelf> list = retval.getBookshelf();
		for (String name: names) {
			Bookshelf b = of.createBookshelf();
			b.setName(name);
			rutil.completeBookshelf(b);
			list.add(b);
		}
		retval.setPage(page);
		retval.setTotalPages(BigInteger.ONE);
		return retval;
	}
	
	public void removeBookshelf(String name) throws UnknownBookshelfException {
		db.removeBookshelf(name);	
	}
	
	public BookshelfItem addItemToBookshelf(BigInteger id, String name) throws UnknownItemException, UnknownBookshelfException, TooManyItemsException, Exception {
		Item item = getItem(id);
		if (item==null)
			throw new UnknownItemException();
		if (db.addItemToBookshelf(id, name)) {
			BookshelfItem bitem = new BookshelfItem();
			bitem.setItem(item);
			Bookshelf b = of.createBookshelf();
			b.setName(name);
			rutil.completeBookshelf(b);
			bitem.setBookshelf(b.getSelf());
			rutil.completeBookshelfItem(bitem, id);
			return bitem;
		} else return null;
	}

	public boolean removeItemFromBookshelf(BigInteger id, String name) throws UnknownItemException, UnknownBookshelfException, Exception {
		return db.removeItemFromBookshelf(id, name);
	}
	
	public BookshelfItems getBookshelfItems(String name) throws UnknownBookshelfException, Exception {
		ItemPage itemPage = db.getBookshelfItems(name);
		
		BookshelfItems items = new BookshelfItems();
		List<Item> list = items.getItem();
		
		Set<Entry<BigInteger,Item>> set = itemPage.getMap().entrySet();
		for(Entry<BigInteger,Item> entry:set) {
			Item item = entry.getValue();
			rutil.completeItem(item, entry.getKey());
			list.add(item);
		}
		Bookshelf b = of.createBookshelf();
		b.setName(name);
		rutil.completeBookshelf(b);
		items.setBookshelf(b);
		rutil.completeBookshelfItems(items);
		return items;
	}

	public void incrementBookshelfCounter(String name) {
		AtomicLong counter = db.getBookshelfCounter(name);
		if (counter!=null)
			counter.incrementAndGet();
	}
	
	public long incrementAndGetBookshelfCount(String name) throws UnknownBookshelfException {
		AtomicLong counter = db.getBookshelfCounter(name);
		if (counter!=null)
			return counter.incrementAndGet();
		else
			throw new UnknownBookshelfException();
	}

}
