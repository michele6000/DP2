package it.polito.dp2.BIB.sol3.db;

public class UnknownItemException extends Exception {

	public UnknownItemException() {
	}

	public UnknownItemException(String message) {
		super(message);
	}

	public UnknownItemException(Throwable cause) {
		super(cause);
	}

	public UnknownItemException(String message, Throwable cause) {
		super(message, cause);
	}

	public UnknownItemException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
