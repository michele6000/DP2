package it.polito.dp2.BIB.sol3.client;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import it.polito.dp2.BIB.ass3.Bookshelf;
import it.polito.dp2.BIB.ass3.Client;
import it.polito.dp2.BIB.ass3.ItemReader;
import it.polito.dp2.BIB.ass3.ServiceException;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.ProcessingException;

public class ClientImpl implements Client {
	javax.ws.rs.client.Client client;
	WebTarget mainTarget;			// target of the main resource
	WebTarget bookshelvesTarget;	// target of the bookshelves resource
	WebTarget itemsTarget;			// target of the items resource
	String defaultURIString = "http://localhost:8080/BiblioSystem/rest";
	URI uri=null;
	static String uriProperty = "it.polito.dp2.BIB.ass3.URL";
	static String portProperty = "it.polito.dp2.BIB.ass3.PORT";
	private ObjectFactory of = new ObjectFactory();

	public ClientImpl() throws URISyntaxException {
		String uriString = System.getProperty(uriProperty);
		if(uriString!=null) {
			System.out.println("Using URI: "+uriString);
			uri= new URI(uriString);
		} else {
			System.out.println("Using default URI because URL property not set: "+defaultURIString);
			uri= new URI(defaultURIString);
		}
		// create the Client object
		client = ClientBuilder.newClient();
		// create a web target for the main URI
		mainTarget = client.target(uri).path("biblio");
		// and a target for the bookshelves and items resources
		Biblio biblio = mainTarget.request(MediaType.APPLICATION_XML).get(Biblio.class);
		itemsTarget = client.target(new URI(biblio.getItems()));
		bookshelvesTarget = client.target(new URI(biblio.getBookshelves()));
	}

	@Override
	public Bookshelf createBookshelf(String name) throws ServiceException {

		//String regex = "^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$";
		//if (name == null || name.isEmpty() || !name.matches(regex)) {
		//	throw new ServiceException("Wrong formt: name must contains only alphanumeric characters");
		//}
		if (name==null)
			throw new ServiceException("Cannot create bookshelf with null name");

		it.polito.dp2.BIB.sol3.client.Bookshelf newBookshelf = of.createBookshelf();
		newBookshelf.setName(name);

		try {
			Response response = bookshelvesTarget.path(name).request(MediaType.APPLICATION_XML).put(Entity.xml(newBookshelf));

			if (response.getStatus() != 201)
				throw new ServiceException();

			Bookshelves.Bookshelf addedBookshelf = response.readEntity(Bookshelves.Bookshelf.class);

			return new BookshelfImpl(addedBookshelf, bookshelvesTarget);

		} catch (WebApplicationException | ProcessingException e) {
			throw new ServiceException();
		}

	}

	@Override
	public Set<Bookshelf> getBookshelfs(String name) throws ServiceException {
		Set<Bookshelf> retval = new HashSet<Bookshelf>();

		try {
			Bookshelves bookshelvesResponse = bookshelvesTarget.queryParam("prefix", name).queryParam("page", 1)
					.request(MediaType.APPLICATION_JSON_TYPE).get(Bookshelves.class);
	
			for (Bookshelves.Bookshelf bookshelf : bookshelvesResponse.getBookshelf()) {
				retval.add(new BookshelfImpl(bookshelf, bookshelvesTarget));
			}
	
			return retval;
		} catch (WebApplicationException | ProcessingException e) {
			throw new ServiceException();
		}

	}

	@Override
	public Set<ItemReader> getItems(String keyword, int since, int to) throws ServiceException {
		Set<ItemReader> itemSet = new HashSet<ItemReader>();
		Items items = itemsTarget.queryParam("keyword", keyword).queryParam("beforeInclusive", to)
				.queryParam("afterInclusive", since).request(MediaType.APPLICATION_JSON_TYPE).get(Items.class);

		for (it.polito.dp2.BIB.sol3.client.Items.Item i : items.getItem()) {
			itemSet.add(new ItemReaderImpl(i));
		}
		return itemSet;
	}

	// additional test method
	void printItems() throws ServiceException {
		Set<ItemReader> set = getItems("", 0, 3000);
		System.out.println("Items returned: " + set.size());

		// For each Item print related data
		for (ItemReader item : set) {
			System.out.println("Title: " + item.getTitle());
			if (item.getSubtitle() != null)
				System.out.println("Subtitle: " + item.getSubtitle());
			System.out.print("Authors: ");
			String[] authors = item.getAuthors();
			System.out.print(authors[0]);
			for (int i = 1; i < authors.length; i++)
				System.out.print(", " + authors[i]);
			System.out.println(";");

			Set<ItemReader> citingItems = item.getCitingItems();
			System.out.println("Cited by " + citingItems.size() + " items:");
			for (ItemReader citing : citingItems) {
				System.out.println("- " + citing.getTitle());
			}
			printLine('-');

		}
		printBlankLine();
	}

	void printBlankLine() {
		System.out.println(" ");
	}

	void printLine(char c) {
		System.out.println(makeLine(c));
	}

	StringBuffer makeLine(char c) {
		StringBuffer line = new StringBuffer(132);

		for (int i = 0; i < 132; ++i) {
			line.append(c);
		}
		return line;
	}


	// Test main
	public static void main(String[] args) {
		System.setProperty("it.polito.dp2.BIB.BibReaderFactory", "it.polito.dp2.BIB.Random.BibReaderFactoryImpl");
		try {
			ClientImpl mainClient = new ClientImpl();
			mainClient.printItems();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
