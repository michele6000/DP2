package it.polito.dp2.BIB.sol3.service.util;

import java.math.BigInteger;
import java.net.URI;

import javax.ws.rs.core.UriBuilder;

import it.polito.dp2.BIB.sol3.service.jaxb.Bookshelf;
import it.polito.dp2.BIB.sol3.service.jaxb.BookshelfItem;
import it.polito.dp2.BIB.sol3.service.jaxb.BookshelfItems;


public class ResourceUtilsExt extends ResourseUtils {
	UriBuilder bookshelves;

	public ResourceUtilsExt(UriBuilder base) {
		super(base);
		this.bookshelves = base.clone().path("biblio/bookshelves");
	}
	
	public void completeBookshelf(Bookshelf bookshelf) {
		UriBuilder selfBuilder = bookshelves.clone().path(bookshelf.getName());
		UriBuilder itemsBuilder = selfBuilder.clone().path("items");
    	URI self = selfBuilder.build();
    	URI items = itemsBuilder.build();
    	bookshelf.setSelf(self.toString());
    	bookshelf.setItems(items.toString());
	}

	public void completeBookshelfItems(BookshelfItems items) {
		UriBuilder selfBuilder = bookshelves.clone().path(items.getBookshelf().getName()).path("items");
    	URI self = selfBuilder.build();
		items.setSelf(self.toString());
	}

	public void completeBookshelfItem(BookshelfItem bitem, BigInteger id) {
		UriBuilder selfBuilder = UriBuilder.fromUri(bitem.getBookshelf()).path(id.toString());
    	URI self = selfBuilder.build();
		bitem.setSelf(self.toString());
	}

}
