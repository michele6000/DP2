package it.polito.dp2.BIB.sol3.db;

import java.util.Collection;
import java.util.concurrent.ConcurrentSkipListMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.math.BigInteger;
import java.util.concurrent.*;

public class BookshelvesDB {
	private static BookshelvesDB bookshelvesDB = new BookshelvesDB();
	private ConcurrentSkipListMap<String,Bookshelf> bookshelvesByName;

	private BookshelvesDB() {
		bookshelvesByName = new ConcurrentSkipListMap<String,Bookshelf>();
	}
	
	public static BookshelvesDB getBookshelvesDB() {
		return bookshelvesDB;
	}
	
	/**
	 * Create a new bookshelf in the DB
	 * @param name the name of the bookshelf to be created
	 * @return an object that represents the created bookshelf or null if the bookshelf could not be created because the name is null or a bookshelf with the same name already exists
	 */
	public Bookshelf createBookshelf (String name) {
		if (name==null)
			return null;
		Bookshelf bookshelf = new Bookshelf(name);
		if (bookshelvesByName.putIfAbsent(name, bookshelf)==null)
			return bookshelf;
		else
			return null;
	}
	
	/**
	 * Remove the bookshelf with the given name from the DB
	 * param name the name of the bookshelf to be removed
	 * @return an object that represents the bookshelf with the given name or null if it does not exist
	 */
	public Bookshelf removeBookshelf (String name) {
		return bookshelvesByName.remove(name);
	}
	
	/**
	 * Get the bookshelf with the given name
	 * @param name the name of the bookshelf to be retrieved
	 * @return an object that represents the selected bookshelf or null if it does not exist
	 */
	public Bookshelf getBookshelf (String name) {
		return bookshelvesByName.get(name);
	}
	
	/**
	 * Get all the bookshelves in the DB, whose names match a given prefix
	 * @param prefix the prefix
	 * @return a collection of objects that represent the selected bookshelves
	 */
	public Collection<Bookshelf> getBookshelves (String prefix) {
		String next = prefix;
		while (next.length()>0) {
			char nextc = (next.charAt(next.length()-1)); // find successor of last character in next
			nextc++;
			System.out.println("nextc is:"+nextc);
			next = next.substring(0, next.length()-1);  // remove last character from next
			System.out.println("next is:"+next);
			if (nextc!=0) { 	// if there was a successor
				next += Character.toString(nextc);	// add successor to next
				break;			// and stop the loop
			}
		}
		System.out.println("next is:"+next);
		if (next.length()>0)
			return bookshelvesByName.tailMap(prefix).headMap(next).values();
		else
			return bookshelvesByName.tailMap(prefix).values();
	}

}
