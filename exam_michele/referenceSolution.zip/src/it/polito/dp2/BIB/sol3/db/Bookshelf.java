package it.polito.dp2.BIB.sol3.db;

import java.math.BigInteger;
import java.util.Collection;
import java.util.HashSet;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

public class Bookshelf implements Comparable<Bookshelf> {

	private String name;	// the immutable name of the Bookshelf
	private ConcurrentSkipListSet<BigInteger> items;
	private BookshelfCounter available;
	private boolean destroyed;
	private AtomicLong counter;
	
	public Bookshelf(String name) {
		this.name = name;
		items = new ConcurrentSkipListSet<BigInteger>();
		available = new BookshelfCounter();
		destroyed = false;
		counter = new AtomicLong(0);
	}

	/**
	 * Get the (immutable) name of this bookshelf
	 * @return the name of this bookshelf
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Add an item with a given id to the bookshelf
	 * @param id the id of the item to be added
	 * @return true if the item was not already in the bookshelf and it has been added
	 * @throws TooManyItemsException if the item cannot be added because there are already too many items in the bookshelf
	 */
	public boolean addItem(BigInteger id) throws TooManyItemsException {
		if (available.decrement()) { 	// the item can be added (space has been reserved)
			if (items.add(id))
				return true;		 	// the item has been added
			else {
				available.increment(); 	// the item was already in the bookshelf
				return false;			// release space reservation
			}
		}
		else
			throw new TooManyItemsException();	
	}
	
	/**
	 * Remove an item with a given id from the bookshelf
	 * @param id the id of the item to be removed
	 * @return true if the item was in the bookshelf and it has been removed, false if the bookshelf didn't contain the item
	 */
	public boolean removeItem(BigInteger id) {
		if (items.remove(id)) {		// the bookshelf contained the item; the item has been removed
			available.increment();	// release space reservation
			return true;
		} else
			return false;			// the bookshelf didn't contain the item
	}
	
	/**
	 * Get the ids of the items in the bookshelf
	 * @return a collection containing the ids
	 */
	public Collection<BigInteger> getItems() {
		return new HashSet<BigInteger>(items);
	}
	
	public void destroy() {
		destroyed = true;
	}
	
	/**
	 * Get the maximum number of items this bookshelf can have
	 * @return the maximum
	 */
	public int getMax() {
		return available.getMax();
	}

	public AtomicLong getCounter() {
		return counter;
	}

	@Override
	public int compareTo(Bookshelf o) {
		return this.name.compareTo(o.getName());
	}
	
}
