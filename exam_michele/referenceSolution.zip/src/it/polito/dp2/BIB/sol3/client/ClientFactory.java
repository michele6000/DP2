package it.polito.dp2.BIB.sol3.client;

import java.net.URI;
import java.net.URISyntaxException;

import it.polito.dp2.BIB.ass3.Client;
import it.polito.dp2.BIB.ass3.ClientException;

public class ClientFactory extends it.polito.dp2.BIB.ass3.ClientFactory{

	@Override
	public Client newClient() throws ClientException {
		try {
			return new ClientImpl();
		} catch (Exception e) {
			throw new ClientException(e);
		}
	}

}
