package it.polito.dp2.BIB.sol3.resources;

import it.polito.dp2.BIB.sol3.service.jaxb.*;
import it.polito.dp2.BIB.sol3.db.TooManyItemsException;
import it.polito.dp2.BIB.sol3.db.UnknownBookshelfException;
import it.polito.dp2.BIB.sol3.db.UnknownItemException;
import it.polito.dp2.BIB.sol3.service.BiblioServiceExt;

import java.math.BigInteger;
import java.net.URI;

import javax.ws.rs.BadRequestException;
import javax.ws.rs.ClientErrorException;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.InternalServerErrorException;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Path("/biblio/bookshelves")
@Api(value = "/biblio/bookshelves")
public class BookshelfResources {
	public UriInfo uriInfo;
	CounterImpl counter;
	
	BiblioServiceExt service;


	public BookshelfResources(@Context UriInfo uriInfo) {
		this.uriInfo = uriInfo;
		this.service = new BiblioServiceExt(uriInfo);
		counter = CounterImpl.getCounter();
	}
	
	@GET
    @ApiOperation(value = "getBookshelves", notes = "search bookshelves"
	)
    @ApiResponses(value = {
    		@ApiResponse(code = 200, message = "OK", response=Bookshelves.class),
    		})
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public Bookshelves getBookshelves(
			@ApiParam("The name prefix to be used for the search") @QueryParam("prefix") @DefaultValue("") String prefix,
			@ApiParam("The page of results to be read") @QueryParam("page") @DefaultValue("1") int page
			) {
		try {
			return service.getBookshelves(prefix, BigInteger.valueOf(page));
		} catch (Exception e) {
			throw new InternalServerErrorException(e);
		}
	}

	@GET
	@Path("/{name}")
    @ApiOperation(value = "getBookshelf", notes = "read Bookshelf"
	)
    @ApiResponses(value = {
    		@ApiResponse(code = 200, message = "OK", response=Bookshelf.class),
    		@ApiResponse(code = 404, message = "Not Found"),
    		})
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public Bookshelf getBookshelf(
			@ApiParam("The name of the bookshelf") @PathParam("name") String name) {
		Bookshelf retval;
		try {
			retval = service.getBookshelf(name);
			service.incrementBookshelfCounter(name);
		} catch (Exception e) {
			throw new InternalServerErrorException(e);
		}
		if (retval==null)
			throw new NotFoundException();
		else
			return retval;
	}

	@PUT
	@Path("/{name}")
    @ApiOperation(value = "createBookshelf", notes = "create a new bookshelf", response=Bookshelf.class
	)
    @ApiResponses(value = {
    		@ApiResponse(code = 201, message = "OK", response=Bookshelf.class),
    		@ApiResponse(code = 409, message = "Conflict"),
    		})
	@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public Response createBookshelf(@ApiParam("The name of the bookshelf") @PathParam("name") String name, Bookshelf bookshelf) throws Exception {
		try {
			Bookshelf b = service.createBookshelf(bookshelf.getName());
			if (b==null)
				throw new ClientErrorException(409);
			return Response.created(new URI(b.getSelf())).entity(b).build();
		} catch (Exception e1) {
			throw new InternalServerErrorException();
		}
	}
	
	@DELETE
	@Path("/{name}")
    @ApiOperation(value = "deleteBookshelf", notes = "delete a bookshelf"
	)
    @ApiResponses(value = {
    		@ApiResponse(code = 204, message = "No content"),
    		@ApiResponse(code = 404, message = "Not Found"),
    		})
	public void deleteBookshelf (
			@ApiParam("The name of the bookshelf") @PathParam("name") String name) {
			try {
				service.removeBookshelf(name);
			} catch (UnknownBookshelfException e) {
				throw new NotFoundException();
			} catch (Exception e1) {
				throw new InternalServerErrorException();
			}
			return;
	}
	
	@GET
	@Path("/{name}/items")
    @ApiOperation(value = "getBookshelfItems", notes = "get the items that are in a bookshelf"
	)
    @ApiResponses(value = {
    		@ApiResponse(code = 200, message = "OK", response=BookshelfItems.class),
    		@ApiResponse(code = 404, message = "Not Found"),
    		})
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public BookshelfItems getBookshelfItems (
			@ApiParam("The name of the bookshelf") @PathParam("name") String name) {
		BookshelfItems items;
		try {
			items = service.getBookshelfItems(name);
			service.incrementBookshelfCounter(name);
		} catch (UnknownBookshelfException e) {
			throw new NotFoundException();
		} catch (Exception e) {
			throw new InternalServerErrorException();
		}
		return items;
	}

	@GET
	@Path("/{name}/reads")
    @ApiOperation(value = "getBookshelfReads", notes = "get the number of times the bookshelf has been read"
	)
    @ApiResponses(value = {
    		@ApiResponse(code = 200, message = "OK"),
    		@ApiResponse(code = 404, message = "Not Found"),
    		})
	@Produces({MediaType.TEXT_PLAIN})
	public long getBookshelfIReads (
			@ApiParam("The name of the bookshelf") @PathParam("name") String name) {
		
		try {
			return service.incrementAndGetBookshelfCount(name);
		} catch (UnknownBookshelfException e) {
			throw new NotFoundException();
		} catch (Exception e) {
			throw new InternalServerErrorException();
		}
	}

	@PUT
	@Path("/{name}/items/{id}")
    @ApiOperation(value = "addItemToBookshelf", notes = "add an item to a Bookshelf", response=Citation.class
	)
    @ApiResponses(value = {
    		@ApiResponse(code = 200, message = "OK", response=BookshelfItem.class),
    		@ApiResponse(code = 201, message = "Created", response=BookshelfItem.class),
    		@ApiResponse(code = 400, message = "Bad Request"),
    		@ApiResponse(code = 404, message = "Not Found"),
    		})
	@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public Response addItemToBookshelf (
			@ApiParam("The name of the bookshelf") @PathParam("name") String name,
			@ApiParam("The id of the item") @PathParam("id") BigInteger id,
			BookshelfItem bitem) {
		BookshelfItem retval;
		try {
			retval = service.addItemToBookshelf(id, name);			
			if (retval==null)
				return Response.noContent().build();
			else
				return Response.created(new URI(retval.getSelf())).entity(retval).build();
		} catch (UnknownItemException e) {
			throw new BadRequestException();
		} catch (UnknownBookshelfException e) {
			throw new NotFoundException();
		} catch (TooManyItemsException e) {
			throw new ClientErrorException(409);
		} catch (Exception e) {
			throw new InternalServerErrorException();
		}
		 	
	}
	
	@DELETE
	@Path("/{name}/items/{id}")
    @ApiOperation(value = "removeItemFromBookshelf", notes = "remove an item from a bookshelf"
	)
    @ApiResponses(value = {
    		@ApiResponse(code = 204, message = "No content", response=Citation.class),
    		@ApiResponse(code = 404, message = "Not Found"),
    		})
	public void removeItemFromBookshelf (
			@ApiParam("The name of the bookshelf") @PathParam("name") String name, 
			@ApiParam("The id of the item") @PathParam("id") BigInteger id) {
		boolean success;
		try {
			success=service.removeItemFromBookshelf(id, name);
		} catch (UnknownItemException|UnknownBookshelfException e) {
			throw new NotFoundException();
		} catch (Exception e) {
			throw new InternalServerErrorException();
		}
		if(!success)
			throw new NotFoundException();
		return;
	}
	
}
